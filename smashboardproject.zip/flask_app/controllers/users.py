from crypt import methods
from flask_app import app
from flask import render_template,redirect,request,flash, session
from flask_app.models.user import User
from flask_app.models.coach_event import CoachingEvent
from flask_app.models.game_event import GameEvent
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route('/')
def home():
    if 'id' not in session:
        session['id'] = False
    if 'first_name' not in session:
        session['first_name'] = None
    return render_template("index.html")

@app.route('/register', methods=['POST'])
def registerUser():
    if not User.validate_user(request.form):
        return redirect('/')
    
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    data = {
        "first_name": request.form["first_name"],
        "last_name": request.form["last_name"],
        "gamertag": request.form["gamertag"],
        "main_character": request.form["main_character"],
        "email": request.form["email"],
        "password": pw_hash,
        "confirm-password": request.form['confirm-password']
    }
    session['first_name'] = request.form["first_name"]
    session['user_id'] = User.create(data)
    return redirect('/home')

@app.route('/login', methods=['POST'])
def loginUser():
    data = { "email": request.form['email']}
    user_in_db = User.get_by_email(data)
    if not user_in_db:
        flash("Invalid Email/Password")
        return redirect('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        flash("Invalid Email/Password")
        return redirect('/')
    else:
        session['user_id'] = user_in_db.id
        print(session['user_id'])
        print("@@@@@@@@@")
        session['first_name'] = user_in_db.first_name
        return redirect('/home')

@app.route('/logout')
def logout():

    session.clear()
    return redirect('/')

@app.route('/home')
def board_home():
    all_users = User.get_all()
    return render_template("home.html", user = all_users)

@app.route('/profile/<int:user_id>')
def user_profile(user_id):
    data = {
        'id': user_id,
        }
    user = User.get_one(data)
    return render_template('profile.html', user=user)

@app.route('/edit-profile/<int:user_id>')
def editProfile(user_id):
    data = {
        'id': user_id
    }
    return render_template("editProfile.html", user=User.get_one(data))

@app.route('/edit/<int:user_id>', methods=['POST'])
def updateProfile(user_id):
    data = {
        "id": user_id,
        "first_name" : request.form["first_name"],
        "last_name" : request.form["last_name"],
        "gamertag" : request.form["gamertag"],
        "main_character" : request.form["main_character"]
    }
    User.update(data)
    return redirect('/home')

@app.route('/create-event')
def create_event():
    return render_template('createEvent.html')

@app.route('/create-game')
def create_game():
    return render_template('createGame.html')

@app.route('/create-coaching')
def create_coaching():
    return render_template('createCoaching.html')