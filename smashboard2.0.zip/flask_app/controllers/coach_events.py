from crypt import methods
from flask_app import app
from flask import render_template,redirect,request,flash, session
from flask_app.models.user import User
from flask_app.models.coach_event import CoachingEvent
from flask_app.models.game_event import GameEvent

@app.route("/coaching")
def coachPage():
    coaches = CoachingEvent.get_games_with_coach()
    users = User.get_all()
    user = User.get_one({"id": session["user_id"]})
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    return render_template("coaching.html", all_coaches = coaches, all_users = users)

@app.route("/leave-coaching/<int:coaching_event_id>")
def leaveCoaching(coaching_event_id):
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    data = {
        "user_id": session["user_id"],
        "coaching_event_id": coaching_event_id
    }
    CoachingEvent.leaveCoachSession(data)
    return redirect('/coaching')

@app.route("/create-coach-session", methods=['POST'])
def createCoachSession():
    if not CoachingEvent.validate(request.form):
        return redirect('/create-coaching')
    data = {
        "date_and_time": request.form["date_and_time"],
        "description": request.form["description"],
        "coach": session["user_id"]
    }

    CoachingEvent.create(data)
    return redirect("/home")

@app.route("/join-coaching/<int:coaching_event_id>")
def joinCoaching(coaching_event_id):
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    data = {
        "user_id": session["user_id"],
        "coaching_event_id": coaching_event_id
    }
    CoachingEvent.joinCoachSession(data)
    return redirect('/coaching')