from crypt import methods
from flask_app import app
from flask import render_template,redirect,request,flash, session
from flask_app.models.user import User
from flask_app.models.coach_event import CoachingEvent
from flask_app.models.game_event import GameEvent

@app.route("/games")
def gamePage():
    games = GameEvent.get_all()
    users = User.get_all()
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    return render_template("games.html", all_games = games, all_users = users)