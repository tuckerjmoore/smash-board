from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.controllers import users
from flask_app import app

class CoachingEvent:
    def __init__(self,data):
        self.id = data['id']
        self.date_and_time = data['date_and_time']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

        self.coach = ""

    @classmethod
    def create(cls,data):
        query = "INSERT INTO coaching_events (date_and_time, description, created_at, updated_at) VALUES (%(date_and_time)s, %(description)s, NOW(), NOW());"
        results = connectToMySQL('smashboard_db').query_db(query,data)
        print(results)
        return results

    @classmethod
    def update(cls, data):
        query = "UPDATE coaching_events SET date_and_time=%(date_and_time)s,description=%(description)s, WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,data)

    @classmethod
    def destroy(cls, id):
        query = "DELETE FROM coaching_events WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,id)

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM coaching_events WHERE id = %(id)s"
        coach_from_db = connectToMySQL('smashboard_db').query_db(query,data)

        return cls(coach_from_db[0])

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM coaching_events JOIN users ON shows.user_id = users.id;"
        coaches_from_db =  connectToMySQL('smashboard_db').query_db(query)
        print(coaches_from_db)
        coach_events =[]
        for s in coaches_from_db:
            coach_event = cls(s)
            coach_event.coach = s['gamertag']
            coach_events.append(coach_event)
        return coach_events

    @staticmethod
    def validate(coaching_event):
        is_valid = True
        if len(coaching_event['date_and_time']) < 3:
            flash("You must schedule a date and time for this session.")
            is_valid = False
        if len(coaching_event['description']) < 3:
            flash("Description should be at least 3 characters long")
            is_valid = False
        return is_valid