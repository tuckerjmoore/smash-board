from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app import app
from flask_app.models.coach_event import CoachingEvent
from flask_app.models.game_event import GameEvent
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile(r'^[a-zA-Z]+$')

class User:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.gamertag = data['gamertag']
        self.main_character = data['main_character']
        self.email= data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

        self.shows = []

    @classmethod
    def create(cls,data):
        query = "INSERT INTO users (first_name,last_name,gamertag,main_character,email,password,created_at,updated_at) VALUES (%(first_name)s,%(last_name)s,%(gamertag)s,%(main_character)s,%(email)s,%(password)s,NOW(),NOW())"
        result = connectToMySQL('smashboard_db').query_db(query,data)
        print(result)
        return result

    @staticmethod
    def validate_user(user):
        is_valid = True
        if len(user['first_name']) < 3:
            flash("First Name must be 3 characters or more.")
            is_valid = False
        if len(user['last_name']) < 3:
            flash("Last Name must be 3 characters or more.")
            is_valid = False
        if len(user['gamertag']) < 1:
            flash("You must enter a gamertag. You can always change it later.")
            is_valid = False
        if len(user['main_character']) < 1:
            flash("You must select a main. You can always change it later.")
            is_valid = False
        if not EMAIL_REGEX.match(user['email']): 
            flash("Invalid email address!")
            is_valid = False
        if len(user['password']) < 8:
            flash("Password must be 8 characters or more.")
            is_valid = False
        if user['confirm-password'] != user['password']:
            flash("The passwords do not match.")
            is_valid = False
        return is_valid

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL('smashboard_db').query_db(query)
        users = []
        for user in results:
            users.append( cls(user) )
        return users

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        user_from_db = connectToMySQL('smashboard_db').query_db(query,data)

        return cls(user_from_db[0])

    @classmethod
    def get_by_email(cls,data):
        query = "SELECT * FROM users WHERE email = %(email)s"
        result = connectToMySQL("smashboard_db").query_db(query,data)
        
        if len(result) < 1:
            return False
        return cls(result[0])

    @classmethod
    def update(cls, data):
        query = "UPDATE users SET first_name=%(first_name)s,last_name=%(last_name)s,gamertag=%(gamertag)s,main_character=%(main_character)s WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,data)
