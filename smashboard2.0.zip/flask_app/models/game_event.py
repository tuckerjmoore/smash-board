from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.controllers import users
from flask_app import app
from flask_app.models import user

class GameEvent:
    def __init__(self,data):
        self.id = data['id']
        self.date_and_time = data['date_and_time']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

        self.challenger = ""
        self.challenger_id = ""
        self.challenger_gamertag = ""
        self.challenger_character = ""
        self.user_id = data['user_id']

    @classmethod
    def create(cls,data):
        query = "INSERT INTO game_events (date_and_time, description, user_id, created_at, updated_at) VALUES (%(date_and_time)s, %(description)s, %(challenger)s, NOW(), NOW());"
        results = connectToMySQL('smashboard_db').query_db(query,data)
        print(results)
        return results

    @classmethod
    def update(cls, data):
        query = "UPDATE game_events SET date_and_time=%(date_and_time)s,description=%(description)s, WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,data)

    @classmethod
    def destroy(cls, id):
        query = "DELETE FROM game_events WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,id)

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM game_events WHERE id = %(id)s"
        game_from_db = connectToMySQL('smashboard_db').query_db(query,data)

        return cls(game_from_db[0])

    @classmethod
    def joinGameSession(cls, data):
        query = "INSERT INTO users_and_game_events (user_id, game_event_id) VALUES (%(user_id)s, %(game_event_id)s)"
        return connectToMySQL('smashboard_db').query_db(query, data)

    @classmethod
    def leaveGameSession(cls, data):
        query = "DELETE FROM users_and_game_events WHERE user_id = %(user_id)s and game_event_id = %(game_event_id)s"
        return connectToMySQL('smashboard_db').query_db(query, data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM game_events JOIN users ON game_events.user_id = users.id;"
        games_from_db =  connectToMySQL('smashboard_db').query_db(query)
        print(games_from_db)
        games =[]
        for s in games_from_db:
            game = cls(s)
            game.challenger = s['gamertag']
            games.append(game)
        return games

    @classmethod
    def get_games_with_challenger(cls):
        query = "SELECT * FROM game_events "
        results = connectToMySQL('smashboard_db').query_db(query)
        game_events = []
        for row_from_db in results:
            game_event = cls(row_from_db)
            # user_data = {
            #     "id" : row_from_db["id"],
            #     "date_and_time" : row_from_db["date_and_time"],
            #     "description": row_from_db["description"],
            #     "challenger": row_from_db["users.gamertag"],
            #     "created_at": row_from_db["created_at"],
            #     "updated_at": row_from_db["updated_at"]
            # }
            game_event.challenger = user.User.get_one({"id": row_from_db['user_id']})
            game_event.challengers = cls.get_challengers({"id": row_from_db['id']})
            print(game_event.challengers)
            # game_event.challenger_gamertag = row_from_db["users.gamertag"]
            # game_event.challenger_character = row_from_db["users.main_character"]
            game_events.append(game_event)
        return game_events

    @classmethod
    def get_challengers(cls, data):
        query = "SELECT users.* FROM users JOIN users_and_game_events g ON users.id = g.user_id WHERE g.game_event_id = %(id)s"
        results = connectToMySQL('smashboard_db').query_db(query, data)
        challengers = []
        if not results:
            return challengers
        for row in results:
            challengers.append(user.User(row))
        return challengers

    @staticmethod
    def validate(game_event):
        is_valid = True
        if len(game_event['date_and_time']) < 3:
            flash("You must schedule a date and time for this session.")
            is_valid = False
        if len(game_event['description']) < 3:
            flash("Description should be at least 3 characters long")
            is_valid = False
        return is_valid