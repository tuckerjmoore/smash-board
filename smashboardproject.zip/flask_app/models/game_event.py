from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.controllers import users
from flask_app import app

class GameEvent:
    def __init__(self,data):
        self.id = data['id']
        self.date_and_time = data['date_and_time']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

        self.challenger = []

    @classmethod
    def create(cls,data):
        query = "INSERT INTO game_events (date_and_time, description, created_at, updated_at) VALUES (%(date_and_time)s, %(description)s, NOW(), NOW());"
        results = connectToMySQL('smashboard_db').query_db(query,data)
        print(results)
        return results

    @classmethod
    def update(cls, data):
        query = "UPDATE game_events SET date_and_time=%(date_and_time)s,description=%(description)s, WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,data)

    @classmethod
    def destroy(cls, id):
        query = "DELETE FROM game_events WHERE id = %(id)s"
        return connectToMySQL('smashboard_db').query_db(query,id)

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM game_events WHERE id = %(id)s"
        game_from_db = connectToMySQL('smashboard_db').query_db(query,data)

        return cls(game_from_db[0])

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM game_events JOIN users ON game_events.user_id = users.id;"
        games_from_db =  connectToMySQL('smashboard_db').query_db(query)
        print(games_from_db)
        games =[]
        for s in games_from_db:
            game = cls(s)
            game.challenger = s['gamertag']
            game.append(game)
        return games

    @classmethod
    def get_games_with_challenger(cls, data):
        query = "SELECT * FROM game_events LEFT JOIN users_and_game_events on users_and_game_events.game_event_id = game_events.id LEFT JOIN users ON users_and_game_events.user_id = users.id WHERE game_events.id = %(id)s"
        results = connectToMySQL('smashboard_db').query_db(query, data)
        game_event = cls(results[0])
        for row_from_db in results:
            game_event_data = {
                "id" : row_from_db["id"],
                "date_and_time" : row_from_db["date_and_time"],
                "description": row_from_db["description"],
                "challenger": row_from_db["users.gamertag"],
                "created_at": row_from_db["created_at"],
                "updated_at": row_from_db["updated_at"]
            }
        game_event.challenger.append( game_event.Game_Event( game_event_data ) )
        return game_event

    @staticmethod
    def validate(game_event):
        is_valid = True
        if len(game_event['date_and_time']) < 3:
            flash("You must schedule a date and time for this session.")
            is_valid = False
        if len(game_event['description']) < 3:
            flash("Description should be at least 3 characters long")
            is_valid = False
        return is_valid