from crypt import methods
from flask_app import app
from flask import render_template,redirect,request,flash, session
from flask_app.models.user import User
from flask_app.models.coach_event import CoachingEvent
from flask_app.models.game_event import GameEvent

@app.route("/games")
def gamePage():
    games = GameEvent.get_games_with_challenger()
    users = User.get_all()
    user = User.get_one({"id": session["user_id"]})
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    return render_template("games.html", all_games = games, all_users = users)

@app.route("/create-game-session", methods=['POST'])
def createGameSession():
    if not GameEvent.validate(request.form):
        return redirect('/create-game')
    data = {
        "date_and_time": request.form["date_and_time"],
        "description": request.form["description"],
        "challenger": session["user_id"]
    }

    GameEvent.create(data)
    return redirect('/home')

@app.route("/leave-game/<int:game_event_id>")
def leaveGame(game_event_id):
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    data = {
        "user_id": session["user_id"],
        "game_event_id": game_event_id
    }
    GameEvent.leaveGameSession(data)
    return redirect('/games')

@app.route("/join-game/<int:game_event_id>")
def acceptChallenge(game_event_id):
    if 'user_id' not in session:
        flash("Please log in or register and try again.")
        return redirect('/')
    data = {
        "user_id": session["user_id"],
        "game_event_id": game_event_id
    }
    GameEvent.joinGameSession(data)
    return redirect('/games')
